# InmisAddon
InmisAddon is an addon for the [Inmis](https://github.com/Draylar/inmis) mod.

### Installation
InmisAddon is a mod built for the [Fabric Loader](https://fabricmc.net/). It requires [Inmis](https://www.curseforge.com/minecraft/mc-mods/inmis) to be installed; all other dependencies are installed with the mod.

### License
InmisAddon is licensed under MIT.
